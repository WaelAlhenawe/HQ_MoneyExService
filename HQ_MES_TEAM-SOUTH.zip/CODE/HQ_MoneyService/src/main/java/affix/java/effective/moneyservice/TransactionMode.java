package affix.java.effective.moneyservice;
/**
 * 
 * This class holds the TransactionMode as Enums for Buy and Sell
 * @author Team South
 *
 */
public enum TransactionMode {

	BUY,
	SELL;
}
